
import numpy as np
import pandas as pd
import sklearn
import matplotlib.pyplot as plt
import seaborn as sns
#importação dos arquivos excel para o Python



corridas = pd.read_csv('AllRace.csv')
pilotos =pd.read_csv('DriversStandings.csv')
construtores = pd.read_csv('ConstructorStandings.csv')

#Análise dos dados
#--------------------

#Ver as primeiras linhas da base de dados - Corridas
corridas.head()

#Ver as estatisticas da base de dados - Pilotos
pilotos.describe()

#contar o número de corridas por temporada
corridas.groupby('Date').size()

#TRATAMENTO DE DADOS
#---------------------

#Limpar dados ausentes
corridas.dropna(inplace=True)

#Seleção de variáveis para previsão da pole position
variaveis = ['Circuito', 'Date']
corridas = corridas[variaveis]

#Converter data pro tipo numérico
corridas['Date'] =pd.to_datetime(corridas['Date']).astype(int)// 10**9

#Variaveis categoricas
from sklearn.preprocessing import LabelEncoder


labelencoder = LabelEncoder()
corridas['Circuito'] = labelencoder.fit_transform(corridas['Circuito'])
pilotos['Piloto'] = labelencoder.fit_transform(pilotos['Piloto'])
pilotos['Equipe'] = labelencoder.fit_transform(pilotos['Equipe'])


#Análise de desempenho de pilotos
from sklearn.cluster import KMeans

le = LabelEncoder()
pilotos['Nacinalidade'] = le.fit_transform(pilotos['Nacionalidade'])

le = LabelEncoder()
pilotos['Piloto'] = le.fit_transform(pilotos['Piloto'])

le = LabelEncoder()
pilotos['Equipe'] = le.fit_transform(pilotos['Equipe'])

pilotos['Posição'] = pilotos['Posição'].replace('DQ', 9999)
pilotos['Posição'] = pilotos['Posição'].astype(float)


x = pilotos.drop(['Piloto', 'Nacionalidade', 'Equipe'], axis=1)

le = LabelEncoder()
pilotos['Nacinalidade'] = le.fit_transform(pilotos['Nacionalidade'])


kmeans = (KMeans(n_clusters=3, n_init=10))
kmeans.fit(x)


#Análise de desempenho de construtores
x = construtores.drop(['Team'], axis=1)
y = construtores['Posição']






#Aplicando janela deslizante 
#----------------------------------------------------------------------------------------------
#MACHINE LEARNING PARA CALCULAR A PREVISAO DA PONTUAÇÃO DE UMA EQUIPE NA TEMPORADA

from sklearn.tree import DecisionTreeRegressor

#Fazer a união das base de dados de corridas e de equipes
corridas['Date'] = pd.to_datetime(corridas['Date'], unit='s').dt.strftime('%Y-%m-%d')
dados = pd.merge(corridas, construtores, left_on='Date', right_on='Team')
#Agregar dados por temporada e equipe
dados_agrupados = dados.groupby(['Year', 'Team'], as_index=False).agg({'PTS':'sum', 'Posição': 'min'})

#Preparação dos dados
temporadas = sorted(dados_agrupados['Year'].unique())

previsoes = []
for i in range(4, len(temporadas)):
  #Seleção dos dados das ultimas 5 temporadas
  ultimas_temporadas = temporadas[i-4:i+1]
  dados_janela = dados_agrupados[dados_agrupados['Year'].isin(ultimas_temporadas)]
  #Separação de dados de treino e dados de teste
  x = dados_janela.drop(['PTS'], axis=1)
  y = dados_janela['PTS']
  x_treino = x.iloc[:-1]
  y_treino = y.iloc[:-1]
  x_teste = x.iloc[-1:]

  #Criando modelo de regressão
  regressor = DecisionTreeRegressor()
  regressor.fit(x_treino, y_treino)

  #Fazendo a previsão da pontuação da equipe na temporada
  previsao = regressor.predict(x_teste)
  previsoes.append(previsao)

#Colocar tudo em um único dataframe
previsoes_df = pd.DataFrame({'Team': dados_agrupados['Team'].unique(), 'Year': temporadas[4:], 'Pontuacao_Prevista': previsoes})
#-------------------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------
#Criação da matriz de conhecimento 

# Seleção das colunas necessárias
dados_filtrados = dados_agrupados[['Team', 'Year', 'PTS']]

# Criação da tabela por equipe
tabela = pd.pivot_table(dados_filtrados, values='PTS', index=['Team'], columns=['Year'], aggfunc=np.sum)

# Preencher valores vazios


tabela.fillna(0, inplace=True)

# Convertendo a tabela em matriz
matriz_conhecimento = tabela.values

matriz_conhecimento = np.array([[10, 20, 30],
                             [20, 30, 10],
                             [30, 10, 20]])

sns.heatmap(matriz_conhecimento, annot=True, cmap='Blues')
plt.show()


print(matriz_conhecimento)