/*
--------------------------
Pedro Augusto Mendes
Algoritmos e estrutura de dados 1
Professor Bressan
Trabalho 3 - Processamento de imagens
--------------------------
*/

// inserção de bibliotecas
#include <cstdlib>
#include <fstream>
#include <iostream>

using namespace std;

typedef int tImagem[1000][1000];

string erro;

int carregaPGM(string nome, tImagem img, int *lin, int *col, int *tons) {

  string tipo;
  ifstream arquivo(nome);
  if (!arquivo.is_open()) {
    erro = "Erro: Arquivo não encontrado.";
    return 1;
  }

  arquivo >> tipo;
  if (tipo != "P2") {
    erro = "Erro: Arquivo não tem formato P2.";
    return 2;
  }

  arquivo >> *col >> *lin >> *tons;
  for (int i = 0; i < *lin; i++) {
    for (int j = 0; j < *col; j++) {
      arquivo >> img[i][j];
    }
  }
  arquivo.close();
  return 0;
}

int salvaPGM(string nome, tImagem img, int linhas, int colunas, int tons) {
  ofstream arquivo(nome);
  if (!arquivo.is_open()) {
    erro = "Erro: Arquivo não encontrado.";
    return 1;
  }
  arquivo << "P2" << endl << colunas << " " << linhas << endl << tons << endl;
  for (int i = 0; i < linhas; i++) {
    for (int j = 0; j < colunas; j++) {
      arquivo << img[i][j] << " ";
    }
    arquivo << endl;
  }
  arquivo.close();
  return 0;
}

float escurecer_ou_clarear(int img[][1000], int lin, int col,
                           double fator_img) {
  int tons = 255; // O número máximo de tons da imagem é 255 (imagem PGM em
                  // escala de cinza).

  for (int i = 0; i < lin; i++) {
    for (int j = 0; j < col; j++) {
      // Aplique o ajuste de clarear/escurecer
      int nova_intensidade = static_cast<int>(
          img[i][j] * fator_img); // o uso do static_cast é para que não haja
                                  // perda de dados, uma vez que um double pode
                                  // representar tranquilamente um inteiro.

      // Certifique-se de que a nova intensidade permaneça dentro dos limites
      // [0, tons]
      nova_intensidade = max(0, std::min(tons, nova_intensidade));

      // Atualize o valor do pixel com a nova intensidade
      img[i][j] = nova_intensidade;
    }
  }

  // Retorne o fator utilizado (para fins de informação)
  return fator_img;
}

void rotate_left(int img[][1000], int &lin, int &col) {
  int novaImagem[1000][1000];

  // Transpor a imagem (trocar linhas por colunas)
  for (int i = 0; i < lin; i++) {
    for (int j = 0; j < col; j++) {
      novaImagem[col - 1 - j][i] = img[i][j];
    }
  }

  // Atualizar as dimensões da imagem
  swap(lin, col);

  // Copiar a imagem rotacionada de volta para a matriz original
  for (int i = 0; i < lin; i++) {
    for (int j = 0; j < col; j++) {
      img[i][j] = novaImagem[i][j];
    }
  }
}

void rotate_right(int img[][1000], int &lin, int &col) {
  int novaImagem[1000][1000];

  // Transpor a imagem (trocar linhas por colunas, invertendo as direções)
  for (int i = 0; i < lin; i++) {
    for (int j = 0; j < col; j++) {
      novaImagem[j][i] = img[i][col - 1 - j];
    }
  }

  // Atualizar as dimensões da imagem
  swap(lin, col);

  // Copiar a imagem rotacionada de volta para a matriz original
  for (int i = 0; i < lin; i++) {
    for (int j = 0; j < col; j++) {
      img[i][j] = novaImagem[i][j];
    }
  }
}

void reducao_imagem(int img[][1000], int &lin, int &col) {
  int novaImagem[64][64];

  // Tamanho dos blocos para redução
  int tamanhoBlocoLin = lin / 64;
  int tamanhoBlocoCol = col / 64;

  for (int i = 0; i < 64; i++) {
    for (int j = 0; j < 64; j++) {
      // Calcula a média dos pixels no bloco
      int soma = 0;
      for (int x = 0; x < tamanhoBlocoLin; x++) {
        for (int y = 0; y < tamanhoBlocoCol; y++) {
          soma += img[i * tamanhoBlocoLin + x][j * tamanhoBlocoCol + y];
        }
      }
      novaImagem[i][j] = soma / (tamanhoBlocoLin * tamanhoBlocoCol);
    }
  }

  // Atualizar as dimensões da imagem
  lin = 64;
  col = 64;

  // Copiar a imagem reduzida de volta para a matriz original
  for (int i = 0; i < lin; i++) {
    for (int j = 0; j < col; j++) {
      img[i][j] = novaImagem[i][j];
    }
  }
}

void binarizar_imagem(int img[][1000], int lin, int col,
                      double fator_de_conversao) {
  int tons = 255; // O número máximo de tons da imagem é 255 (imagem PGM em
                  // escala de cinza).

  for (int i = 0; i < lin; i++) {
    for (int j = 0; j < col; j++) {
      // Aplique a binarização
      if (img[i][j] > static_cast<int>(tons * fator_de_conversao)) {
        img[i][j] = 255; // pixel branco
      } else {
        img[i][j] = 0; // pixel preto
      }
    }
  }
}

void filtro_passa_baixa(int img[][1000], int lin, int col) {
  int novaImagem[1000][1000];

  // Tamanho do kernel (filtro de média simples de 3x3)
  int tamanhoKernel = 3;

  for (int i = 1; i < lin - 1; i++) {
    for (int j = 1; j < col - 1; j++) {
      // Calcula a média dos valores dos pixels vizinhos
      int soma = 0;
      for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
          soma += img[i + x][j + y];
        }
      }
      novaImagem[i][j] = soma / (tamanhoKernel * tamanhoKernel);
    }
  }

  // Copiar a imagem filtrada de volta para a matriz original
  for (int i = 1; i < lin - 1; i++) {
    for (int j = 1; j < col - 1; j++) {
      img[i][j] = novaImagem[i][j];
    }
  }
}

void imprimirMenu() {
  cout << "\n========= Menu =========" << endl;
  cout << "1. Carregar imagem de entrada" << endl;
  cout << "2. Escurecer ou clarear a imagem" << endl;
  cout << "3. Rotacionar a imagem para a esquerda" << endl;
  cout << "4. Rotacionar a imagem para a direita" << endl;
  cout << "5. Reduzir a imagem para 64x64 pixels" << endl;
  cout << "6. Binarizar a imagem" << endl;
  cout << "7. Aplicar filtro passa-baixa" << endl;
  cout << "0. Sair" << endl;
  cout << "=========================" << endl;
  cout << "Digite a opção desejada: ";
}

/*
 * Leitura e Escrita de arquivos no formato PGM com funções.
 */
int main(int argc, char **argv) {
  tImagem img_entrada, img_saida;
  int colunas = 10, linhas = 10, tons;
  string arquivo_entrada, arquivo_saida;
  bool imagem_carregada = false;

  int opcao;
  double fator;
  double fator_binarizacao;
  bool executar_programa = true; // Variável para controlar o loop do menu

  while (executar_programa) {
    imprimirMenu();
    cin >> opcao;

    if (opcao == 1) {
      // Carregar imagem de entrada
      cout << " Entre com o nome da imagem de entrada: ";
      cin >> arquivo_entrada;
      arquivo_entrada = arquivo_entrada + ".pgm";
      if (carregaPGM(arquivo_entrada, img_entrada, &linhas, &colunas, &tons) !=
          0) {
        cout << "\n" + erro + "\n";
        return 1;
      }
      imagem_carregada = true;

    } else if (opcao == 2) {
      // Escurecer ou clarear a imagem
      cout << "Entre com o fator para escurecer ou clarear a imagem (maior que "
              "1 para clarear, menor que 1 para escurecer): ";
      cin >> fator;
      escurecer_ou_clarear(img_entrada, linhas, colunas, fator);
      cout << "Coloque o nome do arquivo de saída" << endl;
      cin >> arquivo_saida;
      arquivo_saida = arquivo_saida + ".pgm";
      salvaPGM(arquivo_saida, img_entrada, linhas, colunas, tons);

    } else if (opcao == 3) {
      // Rotacionar a imagem para a esquerda
      rotate_left(img_entrada, linhas, colunas);
      cout << "Coloque o nome do arquivo de saída" << endl;
      cin >> arquivo_saida;
      arquivo_saida = arquivo_saida + ".pgm";
      salvaPGM(arquivo_saida, img_entrada, linhas, colunas, tons);

    } else if (opcao == 4) {
      // Rotacionar a imagem para a direita
      rotate_right(img_entrada, linhas, colunas);
      cout << "Coloque o nome do arquivo de saída" << endl;
      cin >> arquivo_saida;
      arquivo_saida = arquivo_saida + ".pgm";
      salvaPGM(arquivo_saida, img_entrada, linhas, colunas, tons);

    } else if (opcao == 5) {
      // Reduzir a imagem para 64x64 pixels
      reducao_imagem(img_entrada, linhas, colunas);
      cout << "Coloque o nome do arquivo de saída" << endl;
      cin >> arquivo_saida;
      arquivo_saida = arquivo_saida + ".pgm";
      salvaPGM(arquivo_saida, img_entrada, linhas, colunas, tons);

    } else if (opcao == 6) {
      // Binarizar a imagem
      cout << "Entre com o fator para binarização (valor entre 0 e 1): ";
      cin >> fator_binarizacao;
      binarizar_imagem(img_entrada, linhas, colunas, fator_binarizacao);
      cout << "Coloque o nome do arquivo de saída" << endl;
      cin >> arquivo_saida;
      arquivo_saida = arquivo_saida + ".pgm";
      salvaPGM(arquivo_saida, img_entrada, linhas, colunas, tons);

    } else if (opcao == 7) {
      // Aplicar filtro passa-baixa
      if (!imagem_carregada) {
        cout << "Erro: Nenhuma imagem carregada. Carregue a imagem primeiro."
             << endl;
      } else {
        filtro_passa_baixa(img_entrada, linhas, colunas);
        cout << "Coloque o nome do arquivo de saída" << endl;
        cin >> arquivo_saida;
        arquivo_saida = arquivo_saida + ".pgm";
        salvaPGM(arquivo_saida, img_entrada, linhas, colunas, tons);
      }

    } else if (opcao == 0) {
      // Sair
      cout << "Saindo do programa..." << endl;
      executar_programa = false; // Encerra o loop

    } else {
      cout << "Opção inválida. Tente novamente." << endl;
    }
  }

  return 0;
}