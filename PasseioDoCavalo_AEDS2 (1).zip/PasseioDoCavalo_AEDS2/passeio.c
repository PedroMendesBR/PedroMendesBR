#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "passeio.h"

/*Pedro Augusto Mendes 2021.1.08.041
Rickson Pablo Gomes da ROcha 2022.2.08.007
*/

int n, m;

bool teste_posicao(int nova_linha, int nova_coluna, int n, int m, bool ** tabuleiro){
    if (nova_linha >= 0 && nova_linha < n && nova_coluna >= 0 && nova_coluna < m) {
        if (!tabuleiro[nova_linha][nova_coluna]) {
            return (1);
        }
    }

    return (0);
}

void movimentos(int topo, int linha, int coluna, PILHA *pilha){
    //A casa atual recebe os elementos testados 
    pilha[topo].casa.x = linha;
    pilha[topo].casa.y = coluna;

    //Não foi acessado 
    pilha[topo].acessados = 0;
}

// Implementar o trabalho aqui
void computa_passeios(bool **tabuleiro) {
    int topo = -1, linha, coluna, abertos = 0, fechados = 0;
    bool movimento_completo = true;

    int move_hourse[8][2] = {
        {2,1},{1,2},{-1,2},{-2,1},{-2,-1},{-1,-2},{1,-2},{2,-1}
    };

    //Alocando a pilha
    PILHA item[m*n];

    //inicializando o tabuleiro na primeira casa
    linha = 0;
    coluna = 0;
    tabuleiro[linha][coluna] = true;
    topo++;

    movimentos(topo, linha, coluna, item);

    while(topo >= 0){ //Até o fim da pilha
        movimento_completo = true;
        //For para testar os movimentos do cavalo
        for(int i = item[topo].acessados; i < 8; i++){
            //Movimento testado
            linha = item[topo].casa.x + move_hourse[i][0];
            coluna = item[topo].casa.y + move_hourse[i][1];

            //Condicional caso o movimento seja possível
            if (teste_posicao(linha, coluna, n, m, tabuleiro)){
                item[topo].acessados++;
                tabuleiro[linha][coluna] = true; //Tabuleiro na proxima casa recebe True
                topo++;
                movimentos(topo, linha, coluna, item);
                movimento_completo = false;
                break;
            } else {
                item[topo].acessados++; //Se o movimento não é possível, acrescenta em acessados.   
            }
        }

        if(movimento_completo){
            //Caso de tabuleiro completo
            if(topo == (n*m) - 1){
                int i = 0;
                //Agora irá testar os movimentos e se válido, marcará como fechado
                while(i < 8){
                    if((item[topo].casa.x + move_hourse[i][0] == item[0].casa.x) && (item[topo].casa.y + move_hourse[i][1] == item[0].casa.y)){
                        fechados++;
                        break;
                    }
                    i++;
                }
                if (i == 8){ //Se nenhum é fechado, todos são abertos.
                    abertos++;
                }
            }
            //Verificar se esta no final da pilha 
            if(topo > 0){
                tabuleiro[item[topo].casa.x][item[topo].casa.y] = false;
            }
            topo--; //Desempilha uma casa 
        }
    } 
        

    printf("%d\n%d\n", fechados, abertos);
    return;
}
    int n1, m1;
int main(int argc, char* argv[]) {
    ///////////////////////////////////////////////////////////
    /////////////////// Leitor de instâncias //////////////////
    ///////////////// Não deve ser modificado /////////////////
    ///////////////////////////////////////////////////////////
    int instancia_num = -1;
    instancia_num = atoi(argv[1]);
    if (instancia_num <= 0 || instancia_num > 20) {
        printf("Para executar o código, digite ./passeio x\nonde x é um número entre 1 e 20 que simboliza a instância utilizada\n");
        exit(0);
    }
    
    // Tabuleiro do jogo
    bool **tabuleiro = ler_instancia(instancia_num);


    computa_passeios(tabuleiro);

    return (1);
}

bool **ler_instancia(int instancia_num) {
    int i;
    
    // Montando o caminho para a instancia
    char *arquivo_instancia = "./instancias/";
    asprintf(&arquivo_instancia, "%s%d", arquivo_instancia, instancia_num);
    
    // Ponteiro para a instância
    FILE* file;
 
    // Abrindo a instância em modo leitura
    file = fopen(arquivo_instancia, "r");
 
    if (NULL == file) {
        printf("Arquivo de instância não encontrado. Verifique se sua estrutura de diretórios está EXATAMENTE igual ao do Github\n");
        exit(0);
    }

    // Lendo o arquivo da instância
    fscanf (file, "%d", &n);
    fscanf (file, "%d", &m);

    // Alocando o tabuleiro dinamicamente
    // Usando calloc ao invés de malloc para inicializar todo o tabuleiro com zeros
    bool** tabuleiro = (bool**)calloc(n, sizeof(bool*));
    for (i = 0; i < n; i++) {
        tabuleiro[i] = (bool*)calloc(m, sizeof(bool));
    }

    return tabuleiro;
}